/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** Command: kcg66.exe -config E:/Projetos/SCADE_Study/aircraft_tank/Fuel_Management/Simulation/config.txt
** Generation date: 2018-10-12T23:12:45
*************************************************************$ */
#ifndef _KCG_SENSORS_H_
#define _KCG_SENSORS_H_

#include "kcg_types.h"

#endif /* _KCG_SENSORS_H_ */
/* $********** SCADE Suite KCG 32-bit 6.6 (build i19) ***********
** kcg_sensors.h
** Generation date: 2018-10-12T23:12:45
*************************************************************$ */

