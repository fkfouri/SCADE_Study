const char*  pszDllPathname = "Main.dll";
const char*  pszLauncherPathname = "E:/SCADE/Suite/SCADE/bin/SCSSMLNC.exe";
